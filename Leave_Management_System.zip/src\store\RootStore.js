import { makeAutoObservable, runInAction } from 'mobx';
import api from '../utils/api';

class RootStore {
  currentUser = null;
  employees = [];
  leaves = [];
  leaveBalance = 24;
  serverTime = null;

  constructor() {
    makeAutoObservable(this);
    this.hydrateBalance();
  }

  hydrateBalance() {
    const savedBalance = localStorage.getItem('leaveBalance');
    if (savedBalance !== null) {
      this.leaveBalance = parseInt(savedBalance, 10);
    }
  }

  async loadInitialData() {
    try {
      const response = await api.get('/employees');
      runInAction(() => {
        this.employees = response.body;
        if (!this.currentUser && this.employees.length > 0) {
          this.setCurrentUser(this.employees[0]);
        }
      });
    } catch (e) {
      console.error('Failed to load employees', e);
    }
  }

  setCurrentUser(user) {
    this.currentUser = user;
    if (user.role === 'Employee') {
      this.recalculateLeaveBalance();
    }
  }

  async fetchServerTime() {
    try {
      const resp = await api.get('/server-time');
      runInAction(() => {
        this.serverTime = new Date(resp.body.currentTime);
      });
      return this.serverTime;
    } catch (e) {
      console.error('Failed to get server time', e);
      return new Date();
    }
  }

  recalculateLeaveBalance() {
    if (!this.currentUser) return;
    
    // We start with 24 leaves, and deduct approved/pending leaves
    let totalDeductions = 0;
    
    // The requirement says "Deduct leave balance when a new leave is applied".
    // We can also just count days of pending/approved leaves locally if we fetch them.
    // For now, we will manage the `leaveBalance` in memory and persist in localStorage as a bonus point.
    const saved = localStorage.getItem(`leaveBalance_${this.currentUser.id}`);
    if (saved) {
      this.leaveBalance = parseInt(saved, 10);
    } else {
      this.leaveBalance = 24;
    }
  }

  deductLeaveDays(days) {
    this.leaveBalance -= days;
    if (this.currentUser) {
      localStorage.setItem(`leaveBalance_${this.currentUser.id}`, this.leaveBalance);
    }
  }
}

export const store = new RootStore();
