import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { StoreContext } from '../store/StoreContext';
import api from '../utils/api';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title as ChartTitle, Tooltip, Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale, LinearScale, BarElement, ChartTitle, Tooltip, Legend
);

class Dashboard extends Component {
  static contextType = StoreContext;

  state = {
    leaves: [],
    loading: true
  };

  async componentDidMount() {
    try {
      const resp = await api.get('/leaves');
      this.setState({ leaves: resp.body, loading: false });
    } catch(err) {
      this.setState({ loading: false });
    }
  }

  render() {
    const { leaves, loading } = this.state;
    
    if (loading) return <div style={styles.container}>Loading...</div>;

    const total = leaves.length;
    let approved = 0, pending = 0, rejected = 0;
    
    const employeeData = {};

    leaves.forEach(l => {
      if (l.status === 'Approved') approved++;
      if (l.status === 'Pending') pending++;
      if (l.status === 'Rejected') rejected++;

      if (!employeeData[l.employee]) {
        employeeData[l.employee] = 0;
      }
      employeeData[l.employee]++;
    });

    const chartData = {
      labels: Object.keys(employeeData),
      datasets: [
        {
          label: 'Total Leaves Applied',
          data: Object.values(employeeData),
          backgroundColor: '#4dabf7',
        }
      ]
    };

    const chartOptions = {
      responsive: true,
      plugins: {
        legend: { position: 'top' },
        title: { display: true, text: 'Leaves per Employee' },
      },
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 1 } }
      }
    };

    return (
      <div style={styles.container}>
        <div style={styles.card}>
          <h2 style={styles.title}>Admin Dashboard</h2>
          
          <div style={styles.statsGrid}>
            <div style={{...styles.statCard, backgroundColor: '#f1f3f5'}}>
              <h3 style={styles.statTitle}>Total Leaves</h3>
              <p style={styles.statValue}>{total}</p>
            </div>
            <div style={{...styles.statCard, backgroundColor: '#d3f9d8'}}>
              <h3 style={styles.statTitle}>Approved</h3>
              <p style={{...styles.statValue, color: '#2b8a3e'}}>{approved}</p>
            </div>
            <div style={{...styles.statCard, backgroundColor: '#fff3bf'}}>
              <h3 style={styles.statTitle}>Pending</h3>
              <p style={{...styles.statValue, color: '#e67700'}}>{pending}</p>
            </div>
            <div style={{...styles.statCard, backgroundColor: '#ffe3e3'}}>
              <h3 style={styles.statTitle}>Rejected</h3>
              <p style={{...styles.statValue, color: '#c92a2a'}}>{rejected}</p>
            </div>
          </div>

          <div style={styles.chartContainer}>
            <Bar data={chartData} options={chartOptions} />
          </div>

        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    padding: '40px 20px',
    display: 'flex',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    minHeight: 'calc(100vh - 60px)'
  },
  card: {
    backgroundColor: '#fff',
    padding: '30px',
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
    width: '100%',
    maxWidth: '900px',
    animation: 'fadeIn 0.4s ease-in'
  },
  title: {
    marginTop: 0,
    marginBottom: '30px',
    color: '#2b2d42'
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '20px',
    marginBottom: '40px'
  },
  statCard: {
    padding: '20px',
    borderRadius: '8px',
    textAlign: 'center',
    boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
  },
  statTitle: {
    margin: 0,
    fontSize: '1rem',
    color: '#495057'
  },
  statValue: {
    margin: '10px 0 0 0',
    fontSize: '2rem',
    fontWeight: 'bold',
    color: '#2b2d42'
  },
  chartContainer: {
    marginTop: '20px'
  }
};

export default observer(Dashboard);
