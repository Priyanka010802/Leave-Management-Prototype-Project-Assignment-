import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { observer } from 'mobx-react';
import { StoreContext } from '../store/StoreContext';
import { withRouter } from '../utils/withRouter';

class Navbar extends Component {
  static contextType = StoreContext;

  handleRoleChange = (e) => {
    const store = this.context;
    const selectedUserId = e.target.value;
    const user = store.employees.find(emp => emp.id === selectedUserId);
    if (user) {
      store.setCurrentUser(user);
      this.props.router.navigate('/');
    }
  };

  render() {
    const store = this.context;
    const { currentUser, employees, leaveBalance } = store;

    if (!currentUser) return <nav style={styles.nav}>Loading...</nav>;

    return (
      <nav style={styles.nav}>
        <div style={styles.brand}>LeaveMS Prototype</div>
        <div style={styles.links}>
          {currentUser.role === 'Employee' && (
            <>
              <Link to="/" style={styles.link}>Apply Leave</Link>
              <Link to="/my-leaves" style={styles.link}>My Leaves</Link>
              <span style={styles.balanceBadge}>Balance: {leaveBalance} days</span>
            </>
          )}
          {currentUser.role === 'Manager' && (
            <Link to="/team-leaves" style={styles.link}>Team Leaves</Link>
          )}
          {currentUser.role === 'Admin' && (
            <Link to="/dashboard" style={styles.link}>Dashboard</Link>
          )}
        </div>
        <div style={styles.switcher}>
          <label style={{ marginRight: '10px' }}>Simulate Login:</label>
          <select 
            value={currentUser.id} 
            onChange={this.handleRoleChange}
            style={styles.select}
          >
            {employees.map(emp => (
              <option key={emp.id} value={emp.id}>{emp.name} ({emp.role})</option>
            ))}
          </select>
        </div>
      </nav>
    );
  }
}

const styles = {
  nav: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '15px 30px',
    backgroundColor: '#2b2d42',
    color: '#edf2f4',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  },
  brand: {
    fontSize: '1.2rem',
    fontWeight: 'bold',
  },
  links: {
    display: 'flex',
    alignItems: 'center',
    gap: '20px'
  },
  link: {
    color: '#edf2f4',
    textDecoration: 'none',
    fontWeight: '500',
    transition: 'color 0.2s',
  },
  balanceBadge: {
    backgroundColor: '#ef233c',
    color: 'white',
    padding: '4px 10px',
    borderRadius: '12px',
    fontSize: '0.85rem',
    fontWeight: 'bold'
  },
  switcher: {
    display: 'flex',
    alignItems: 'center'
  },
  select: {
    padding: '5px 10px',
    borderRadius: '4px',
    border: '1px solid #8d99ae',
    backgroundColor: '#fff',
    color: '#2b2d42',
    outline: 'none',
    cursor: 'pointer'
  }
};

export default withRouter(observer(Navbar));
