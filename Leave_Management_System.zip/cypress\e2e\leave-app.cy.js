describe('Leave Management System E2E Tests', () => {

  it('fails to apply back-dated leave (Employee View)', () => {
    cy.visit('http://localhost:3000/');
    
    // Ensure we are employee 1
    cy.get('select').select('1');
    
    // Type dates in the past (using 2025 as past date since server acts as 2026)
    cy.get('input[name="startDate"]').type('2025-01-01');
    cy.get('input[name="endDate"]').type('2025-01-05');
    cy.get('textarea[name="reason"]').type('Test Back-dated leave');
    
    cy.get('button[type="submit"]').click();
    
    // Expect error
    cy.contains('Cannot apply leave in the past.').should('be.visible');
  });

  it('persists filters after refresh (Manager View)', () => {
    cy.visit('http://localhost:3000/');
    
    // Switch to Manager
    cy.get('select').select('2'); // ID 2 is Manager
    
    // Go to Team Leaves
    cy.get('a[href="/team-leaves"]').click();
    
    // Apply filters
    cy.get('input[name="employee"]').type('Alice');
    cy.get('select[name="status"]').select('Pending');
    
    // Wait for URL state propagation
    cy.url().should('include', 'employee=Alice');
    cy.url().should('include', 'status=Pending');
    
    // Reload
    cy.reload();
    
    // Check if input fields persisted from URL
    cy.get('input[name="employee"]').should('have.value', 'Alice');
    cy.get('select[name="status"]').should('have.value', 'Pending');
  });

});
