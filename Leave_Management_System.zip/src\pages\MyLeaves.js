import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { StoreContext } from '../store/StoreContext';
import api from '../utils/api';

class MyLeaves extends Component {
  static contextType = StoreContext;

  state = {
    myLeaves: [],
    loading: true
  };

  componentDidMount() {
    this.fetchMyLeaves();
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    const store = this.context;
    if (store.currentUser && this.state.myLeaves.length > 0) {
      // Check if user switched
      if (store.currentUser.id !== this.state.myLeaves[0].employeeId) {
        this.fetchMyLeaves();
      }
    }
  }

  fetchMyLeaves = async () => {
    const store = this.context;
    if (!store.currentUser) return;
    
    this.setState({ loading: true });
    try {
      const resp = await api.get(`/leaves?employeeId=${store.currentUser.id}`);
      this.setState({ myLeaves: resp.body, loading: false });
    } catch (err) {
      console.error(err);
      this.setState({ loading: false });
    }
  };

  render() {
    const { myLeaves, loading } = this.state;

    return (
      <div style={styles.container}>
        <div style={styles.card}>
          <h2 style={styles.title}>My Leaves</h2>
          
          {loading ? (
            <p>Loading...</p>
          ) : myLeaves.length === 0 ? (
            <p>No leaves applied yet.</p>
          ) : (
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Start Date</th>
                  <th style={styles.th}>End Date</th>
                  <th style={styles.th}>Days</th>
                  <th style={styles.th}>Reason</th>
                  <th style={styles.th}>Status</th>
                </tr>
              </thead>
              <tbody>
                {myLeaves.map(leave => (
                  <tr key={leave.id} style={styles.tr}>
                    <td style={styles.td}>{leave.startDate}</td>
                    <td style={styles.td}>{leave.endDate}</td>
                    <td style={styles.td}>{leave.days}</td>
                    <td style={styles.td}>{leave.reason}</td>
                    <td style={styles.td}>
                      <span style={{
                        ...styles.statusBadge,
                        backgroundColor: leave.status === 'Approved' ? '#d3f9d8' : leave.status === 'Rejected' ? '#ffe3e3' : '#fff3bf',
                        color: leave.status === 'Approved' ? '#2b8a3e' : leave.status === 'Rejected' ? '#c92a2a' : '#f59f00'
                      }}>
                        {leave.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    padding: '40px 20px',
    display: 'flex',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    minHeight: 'calc(100vh - 60px)'
  },
  card: {
    backgroundColor: '#fff',
    padding: '30px',
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
    width: '100%',
    maxWidth: '800px',
    animation: 'fadeIn 0.4s ease-in'
  },
  title: {
    marginTop: 0,
    marginBottom: '20px',
    color: '#2b2d42'
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  th: {
    textAlign: 'left',
    padding: '12px',
    backgroundColor: '#f1f3f5',
    color: '#495057',
    borderBottom: '2px solid #dee2e6'
  },
  tr: {
    borderBottom: '1px solid #e9ecef'
  },
  td: {
    padding: '12px',
    color: '#212529'
  },
  statusBadge: {
    padding: '4px 8px',
    borderRadius: '12px',
    fontSize: '0.85rem',
    fontWeight: 'bold',
    display: 'inline-block'
  }
};

export default observer(MyLeaves);
