import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { StoreContext } from '../store/StoreContext';
import { withRouter } from '../utils/withRouter';
import api from '../utils/api';

class ApplyLeave extends Component {
  static contextType = StoreContext;

  state = {
    startDate: '',
    endDate: '',
    reason: '',
    error: '',
    success: '',
    submitting: false
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value, error: '', success: '' });
  };

  handleSubmit = async (e) => {
    e.preventDefault();
    this.setState({ error: '', success: '', submitting: true });
    
    const store = this.context;
    const { startDate, endDate, reason } = this.state;
    
    if (!startDate || !endDate || !reason) {
      this.setState({ error: 'All fields are required', submitting: false });
      return;
    }

    try {
      // Fetch server time for validation
      const serverTimeResp = await api.get('/server-time');
      const serverDate = new Date(serverTimeResp.body.currentTime);
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      serverDate.setHours(0,0,0,0);
      start.setHours(0,0,0,0);
      end.setHours(0,0,0,0);

      if (start < serverDate) {
        this.setState({ error: 'Cannot apply leave in the past.', submitting: false });
        // Bonus: add slight shake animation or just error text
        return;
      }

      if (end < start) {
        this.setState({ error: 'End date must be greater than or equal to start date.', submitting: false });
        return;
      }

      // Calculate days (simple difference)
      const diffTime = Math.abs(end - start);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

      if (diffDays > store.leaveBalance) {
        this.setState({ error: `Not enough leave balance. You only have ${store.leaveBalance} days left.`, submitting: false });
        return;
      }

      // Submit leave
      const leaveData = {
        employeeId: store.currentUser.id,
        employee: store.currentUser.name,
        startDate,
        endDate,
        reason,
        status: 'Pending',
        days: diffDays
      };

      await api.post('/leaves', { json: leaveData });
      
      // Deduct balance
      store.deductLeaveDays(diffDays);

      this.setState({ 
        success: 'Leave applied successfully!', 
        startDate: '', 
        endDate: '', 
        reason: '', 
        submitting: false 
      });

    } catch (err) {
      this.setState({ error: 'Failed to apply leave. Try again.', submitting: false });
    }
  };

  render() {
    const store = this.context;
    
    if (!store.currentUser) return null;

    return (
      <div style={styles.container}>
        <div style={styles.card}>
          <h2 style={styles.title}>Apply for Leave</h2>
          
          {this.state.error && <div style={styles.error}>{this.state.error}</div>}
          {this.state.success && <div style={styles.success}>{this.state.success}</div>}
          
          <form onSubmit={this.handleSubmit} style={styles.form}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Employee Name</label>
              <input 
                type="text" 
                value={store.currentUser.name} 
                disabled 
                style={styles.inputDisabled}
              />
            </div>
            
            <div style={styles.formGroup}>
              <label style={styles.label}>Start Date</label>
              <input 
                type="date" 
                name="startDate" 
                value={this.state.startDate}
                onChange={this.handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>End Date</label>
              <input 
                type="date" 
                name="endDate" 
                value={this.state.endDate}
                onChange={this.handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Reason</label>
              <textarea 
                name="reason" 
                value={this.state.reason}
                onChange={this.handleChange}
                style={{...styles.input, height: '80px', resize: 'vertical'}}
              />
            </div>

            <button 
              type="submit" 
              style={this.state.submitting ? styles.buttonDisabled : styles.button}
              disabled={this.state.submitting}
            >
              {this.state.submitting ? 'Submitting...' : 'Submit Application'}
            </button>
          </form>
        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    padding: '40px 20px',
    display: 'flex',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    minHeight: 'calc(100vh - 60px)'
  },
  card: {
    backgroundColor: '#fff',
    padding: '30px',
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
    width: '100%',
    maxWidth: '500px',
    animation: 'fadeIn 0.4s ease-in'
  },
  title: {
    marginTop: 0,
    marginBottom: '20px',
    color: '#2b2d42'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px'
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '5px'
  },
  label: {
    fontSize: '0.9rem',
    fontWeight: '600',
    color: '#4a4e69'
  },
  input: {
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #ced4da',
    fontSize: '1rem',
    fontFamily: 'inherit'
  },
  inputDisabled: {
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #ced4da',
    fontSize: '1rem',
    backgroundColor: '#e9ecef',
    color: '#6c757d',
    cursor: 'not-allowed'
  },
  button: {
    padding: '12px',
    backgroundColor: '#3a0ca3',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    fontWeight: 'bold',
    cursor: 'pointer',
    marginTop: '10px',
    transition: 'background-color 0.2s'
  },
  buttonDisabled: {
    padding: '12px',
    backgroundColor: '#8d99ae',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    fontWeight: 'bold',
    cursor: 'not-allowed',
    marginTop: '10px'
  },
  error: {
    padding: '10px',
    backgroundColor: '#ffe3e3',
    color: '#c92a2a',
    borderRadius: '6px',
    marginBottom: '15px',
    fontSize: '0.9rem'
  },
  success: {
    padding: '10px',
    backgroundColor: '#d3f9d8',
    color: '#2b8a3e',
    borderRadius: '6px',
    marginBottom: '15px',
    fontSize: '0.9rem'
  }
};

export default observer(ApplyLeave);
