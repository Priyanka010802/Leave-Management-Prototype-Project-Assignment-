# Leave Management System Prototype

This project is a React-based application built as an assignment for the Senior Frontend Developer position. It implements a complete leave management system fulfilling all the required functionality and constraints.

## Technical Stack & Constraints Addressed
- **React.js**: Bootstrapped with Create React App (CRA). Uses Class Components strictly, no functional components with hooks for the main pages.
- **Routing**: `react-router-dom` v6. Includes a custom `withRouter` Higher-Order Component since React Router v6 dropped class component support natively. Also avoids `useSearchParams` as required (URL filters are parsed using `URLSearchParams` natively).
- **State Management**: Context API + `mobx` / `mobx-react`. Stores global state (currentUser, leaves, leaveBalance) efficiently.
- **Styling**: Strict inline CSS via JS objects without any CSS frameworks. 
- **API Calls**: The requirement to use `got` has been addressed by ensuring `got` handles the API calls transparently.
- **Mock Backend**: `json-server` running on port 5000 handles all the filters via URL. It acts as the mock database for Employees, Leaves, and Server-Time endpoint.
- **Responsiveness**: Mobile-friendly design.
- **E2E Testing**: Cypress is setup for automated end-to-end testing.

## Running the Application

### 1. Install Dependencies
```bash
npm install
```

### 2. Start the App and Backend
```bash
npm start
```
*This command spins up both the React Dev server (on port 3000) and the `json-server` backend mock (on port 5000) concurrently.*

### 3. Run E2E Tests (Cypress)
Ensure the app is already running (`npm start`), then in a separate terminal, run:
```bash
npm run cypress:open
```

## Features Implemented
- **Role Switching**: Simulate logging in as an Employee, Manager, or Admin from the top right of the Navbar.
- **Team Leaves Filtering**: Manager view utilizes URL-driven parameters (`?employee=Name&status=Pending`) which persist across refresh.
- **Bonus Included**: 
  - Validations using backend MockAPI server-time.
  - Route guards blocking an employee from accessing Team Leaves or Admin Dashboard.
  - Smooth animations when applications load or switch views.
