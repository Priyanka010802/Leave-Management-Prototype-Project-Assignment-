import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { StoreContext } from '../store/StoreContext';
import { withRouter } from '../utils/withRouter';
import api from '../utils/api';

class TeamLeaves extends Component {
  static contextType = StoreContext;

  state = {
    teamLeaves: [],
    loading: true,
    employeesList: []
  };

  componentDidMount() {
    this.fetchEmployees();
    this.fetchLeavesFromUrl();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.router.location.search !== this.props.router.location.search) {
      this.fetchLeavesFromUrl();
    }
  }

  fetchEmployees = async () => {
    try {
      const resp = await api.get('/employees');
      this.setState({ employeesList: resp.body });
    } catch(err) {}
  };

  fetchLeavesFromUrl = async () => {
    this.setState({ loading: true });
    try {
      // Use URLSearchParams to read query params since useSearchParams is unauthorized
      const query = new URLSearchParams(this.props.router.location.search);
      const employee = query.get('employee') || '';
      const status = query.get('status') || '';

      let url = '/leaves?';
      if (employee) url += `employee_like=${encodeURIComponent(employee)}&`;
      if (status) url += `status=${encodeURIComponent(status)}&`;

      const resp = await api.get(url);
      this.setState({ teamLeaves: resp.body, loading: false });
    } catch (err) {
      this.setState({ loading: false });
    }
  };

  handleFilterChange = (e) => {
    const { name, value } = e.target;
    const query = new URLSearchParams(this.props.router.location.search);
    
    if (value) {
      query.set(name, value);
    } else {
      query.delete(name);
    }

    this.props.router.navigate(`?${query.toString()}`);
  };

  handleAction = async (leaveId, actionStatus) => {
    try {
      const leave = this.state.teamLeaves.find(l => l.id === leaveId);
      if (!leave) return;

      const updatedLeave = { ...leave, status: actionStatus };
      await api.put(`/leaves/${leaveId}`, { json: updatedLeave });
      
      this.fetchLeavesFromUrl();
    } catch(err) {
      console.error(err);
    }
  };

  render() {
    const { teamLeaves, loading, employeesList } = this.state;
    const query = new URLSearchParams(this.props.router.location.search);
    const employeeFilter = query.get('employee') || '';
    const statusFilter = query.get('status') || '';

    return (
      <div style={styles.container}>
        <div style={styles.card}>
          <h2 style={styles.title}>Team Leave Requests</h2>
          
          <div style={styles.filters}>
            <input 
              type="text" 
              name="employee"
              placeholder="Filter by Employee Name" 
              value={employeeFilter}
              onChange={this.handleFilterChange}
              style={styles.input}
            />
            <select 
              name="status"
              value={statusFilter}
              onChange={this.handleFilterChange}
              style={styles.select}
            >
              <option value="">All Statuses</option>
              <option value="Pending">Pending</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>

          {loading ? (
            <p>Loading...</p>
          ) : teamLeaves.length === 0 ? (
            <p>No leave requests found.</p>
          ) : (
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Employee</th>
                  <th style={styles.th}>Dates</th>
                  <th style={styles.th}>Days</th>
                  <th style={styles.th}>Reason</th>
                  <th style={styles.th}>Status</th>
                  <th style={styles.th}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {teamLeaves.map(leave => (
                  <tr key={leave.id} style={styles.tr}>
                    <td style={styles.td}>{leave.employee}</td>
                    <td style={styles.td}>{leave.startDate} to {leave.endDate}</td>
                    <td style={styles.td}>{leave.days}</td>
                    <td style={styles.td}>{leave.reason}</td>
                    <td style={styles.td}>
                       <span style={{
                        ...styles.statusBadge,
                        backgroundColor: leave.status === 'Approved' ? '#d3f9d8' : leave.status === 'Rejected' ? '#ffe3e3' : '#fff3bf',
                        color: leave.status === 'Approved' ? '#2b8a3e' : leave.status === 'Rejected' ? '#c92a2a' : '#f59f00'
                      }}>
                        {leave.status}
                      </span>
                    </td>
                    <td style={styles.td}>
                      {leave.status === 'Pending' && (
                        <div style={styles.actionButtons}>
                          <button 
                            onClick={() => this.handleAction(leave.id, 'Approved')} 
                            style={styles.btnApprove}
                          >
                            Approve
                          </button>
                          <button 
                            onClick={() => this.handleAction(leave.id, 'Rejected')} 
                            style={styles.btnReject}
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    padding: '40px 20px',
    display: 'flex',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    minHeight: 'calc(100vh - 60px)'
  },
  card: {
    backgroundColor: '#fff',
    padding: '30px',
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
    width: '100%',
    maxWidth: '900px',
    animation: 'fadeIn 0.4s ease-in'
  },
  title: {
    marginTop: 0,
    marginBottom: '20px',
    color: '#2b2d42'
  },
  filters: {
    display: 'flex',
    gap: '15px',
    marginBottom: '20px'
  },
  input: {
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #ced4da',
    flex: '1',
    fontSize: '1rem'
  },
  select: {
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #ced4da',
    minWidth: '200px',
    fontSize: '1rem'
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  th: {
    textAlign: 'left',
    padding: '12px',
    backgroundColor: '#f1f3f5',
    color: '#495057',
    borderBottom: '2px solid #dee2e6'
  },
  tr: {
    borderBottom: '1px solid #e9ecef'
  },
  td: {
    padding: '12px',
    color: '#212529'
  },
  statusBadge: {
    padding: '4px 8px',
    borderRadius: '12px',
    fontSize: '0.85rem',
    fontWeight: 'bold',
    display: 'inline-block'
  },
  actionButtons: {
    display: 'flex',
    gap: '10px'
  },
  btnApprove: {
    backgroundColor: '#40c057',
    color: 'white',
    border: 'none',
    padding: '6px 12px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontWeight: 'bold'
  },
  btnReject: {
    backgroundColor: '#fa5252',
    color: 'white',
    border: 'none',
    padding: '6px 12px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontWeight: 'bold'
  }
};

export default withRouter(observer(TeamLeaves));
