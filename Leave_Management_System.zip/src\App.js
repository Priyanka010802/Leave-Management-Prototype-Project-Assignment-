import React, { Component } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { observer } from 'mobx-react';
import { StoreProvider } from './store/StoreContext';
import { store } from './store/RootStore';

import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';

import ApplyLeave from './pages/ApplyLeave';
import MyLeaves from './pages/MyLeaves';
import TeamLeaves from './pages/TeamLeaves';
import Dashboard from './pages/Dashboard';

import './index.css';

class App extends Component {
  componentDidMount() {
    store.loadInitialData();
  }

  render() {
    return (
      <StoreProvider>
        <Router>
          <div className="App">
            <Navbar />
            <Routes>
              <Route path="/" element={<ApplyLeave />} />
              <Route path="/my-leaves" element={<MyLeaves />} />
              
              <Route path="/team-leaves" element={
                <ProtectedRoute allowedRoles={['Manager', 'Admin']}>
                  <TeamLeaves />
                </ProtectedRoute>
              } />
              
              <Route path="/dashboard" element={
                <ProtectedRoute allowedRoles={['Admin']}>
                  <Dashboard />
                </ProtectedRoute>
              } />
            </Routes>
          </div>
        </Router>
      </StoreProvider>
    );
  }
}

export default observer(App);
